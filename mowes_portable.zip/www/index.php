<?php


header("location:start/index.php");

?>